# 复现实验

原运行环境：Python 3.13.14。使用 requirements.txt 中固定的依赖版本。
在解压后的 research 目录执行：

```sh
python -m pip install -r requirements.txt
python train.py
python -m unittest discover -s . -p test_training.py -v
```

train.py 从保留的 UCI 原始压缩包读取数据，重新生成 report.json、predictions.csv、data/ise-returns.csv 以及上级目录的 research-results.js。
如需重新生成网页下载材料，执行 `python package.py`；输出在上级目录。

规则见 EXPERIMENT.md，原运行结果见 RESULTS.md。数据为 CC BY 4.0，作者与来源署名见 EXPERIMENT.md。包内数据已从原 Excel 提取第一列 ISE，并衍生分类特征、标签和报告；原始压缩包未改动。

最终测试已公开，不得把反复修改后在同一区间的成绩称为新的未见测试。原结果：160 条测试记录、准确率 60%、多数类基准 60%，未显示模型优势。不计算投资收益。
