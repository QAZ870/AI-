import json
import shutil
import zipfile
from pathlib import Path


ROOT = Path(__file__).resolve().parent


def main():
    downloads = {
        'report.json': 'research-report.json',
        'predictions.csv': 'research-predictions.csv',
        'data/ise-returns.csv': 'research-source.csv',
        'EXPERIMENT.md': 'research-spec.md',
    }
    files = [
        'train.py', 'test_training.py', 'package.py', 'requirements.txt',
        'EXPERIMENT.md', 'RESULTS.md', 'REPRODUCE.md',
        'data/istanbul-stock-exchange.zip', 'data/ise-returns.csv',
        'report.json', 'predictions.csv',
    ]
    for source, destination in downloads.items():
        shutil.copyfile(ROOT / source, ROOT.parent / destination)
    report = json.loads((ROOT / 'report.json').read_text(encoding='utf-8'))
    with zipfile.ZipFile(ROOT.parent / 'research-reproduce.zip', 'w', zipfile.ZIP_DEFLATED) as archive:
        for filename in files:
            archive.write(ROOT / filename, 'research/' + filename)
    print(f"Packaged {len(files)} files; experiment={report['experiment']}")


if __name__ == '__main__':
    main()
