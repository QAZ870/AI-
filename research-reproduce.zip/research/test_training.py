import copy
import unittest
from datetime import date, timedelta

import numpy as np

from train import build_samples, metrics, read_source, ROOT, run_experiment, split_samples, validate_records


class TrainingTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.records = read_source(ROOT / 'data' / 'istanbul-stock-exchange.zip')

    def test_hand_calculated_lags_and_labels(self):
        records = [{'date': (date(2009, 1, 1) + timedelta(days=index)).isoformat(),
                    'return': float(index)} for index in range(21)]
        sample = build_samples(records)[0]
        np.testing.assert_allclose(sample['features'][:4], [19, 18, 15, 17])
        self.assertAlmostEqual(sample['features'][4], 2 ** 0.5)
        self.assertEqual(sample['features'][5], 9.5)
        self.assertEqual(sample['label'], 1)
        self.assertLess(sample['information_date'], sample['date'])

    def test_future_mutation_does_not_change_prior_features(self):
        changed = copy.deepcopy(self.records)
        changed[100]['return'] = 0.9
        original = build_samples(self.records)
        mutated = build_samples(changed)
        self.assertEqual(original[:80], mutated[:80])
        self.assertEqual(original[80]['features'], mutated[80]['features'])

    def test_test_data_cannot_change_fitting_or_selection(self):
        changed = copy.deepcopy(self.records)
        for record in changed:
            if record['date'] >= '2010-07-01':
                record['return'] = -record['return'] * 10
        original = run_experiment(self.records)
        mutated = run_experiment(changed)
        self.assertEqual(original['fitted'], mutated['fitted'])
        self.assertEqual(original['validation_candidates'], mutated['validation_candidates'])
        self.assertEqual(original['config'], mutated['config'])
        train = split_samples(build_samples(self.records))['train']
        np.testing.assert_allclose(original['fitted']['mean'], np.mean([sample['features'] for sample in train], axis=0))

    def test_partitions_and_information_dates(self):
        samples = build_samples(self.records)
        partitions = split_samples(samples)
        self.assertEqual(sum(len(partition) for partition in partitions.values()), len(samples))
        self.assertLess(partitions['train'][-1]['date'], partitions['validation'][0]['date'])
        self.assertLess(partitions['validation'][-1]['date'], partitions['test'][0]['date'])
        self.assertTrue(all(sample['information_date'] < sample['date'] for sample in samples))

    def test_bad_input_rejected(self):
        for invalid in [None, float('nan'), float('inf'), True]:
            records = copy.deepcopy(self.records)
            records[30]['return'] = invalid
            with self.assertRaises(ValueError):
                validate_records(records)
        records = copy.deepcopy(self.records)
        records[1]['date'] = records[0]['date']
        with self.assertRaises(ValueError):
            validate_records(records)

    def test_metrics_on_known_predictions(self):
        result = metrics(np.array([0, 0, 1, 1]), np.array([0.1, 0.6, 0.8, 0.9]))
        self.assertEqual(result['accuracy'], 0.75)
        self.assertEqual(result['balanced_accuracy'], 0.75)
        self.assertEqual(result['confusion_matrix'], [[1, 1], [0, 2]])

    def test_reproducible(self):
        self.assertEqual(run_experiment(self.records), run_experiment(self.records))


if __name__ == '__main__':
    unittest.main()
