import csv
import hashlib
import io
import json
import platform
import warnings
import zipfile
from datetime import datetime
from pathlib import Path

import numpy as np
import openpyxl
import sklearn
from sklearn.exceptions import ConvergenceWarning
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import accuracy_score, balanced_accuracy_score, confusion_matrix, log_loss, roc_auc_score
from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import StandardScaler


ROOT = Path(__file__).resolve().parent
FEATURES = ['lag_1', 'lag_2', 'lag_5', 'mean_5', 'std_5', 'mean_20', 'std_20']
SOURCE_URL = 'https://archive.ics.uci.edu/dataset/247/istanbul+stock+exchange'
CANDIDATES = [0.01, 0.1, 1.0, 10.0]


def read_source(path):
    with zipfile.ZipFile(path) as archive:
        with warnings.catch_warnings():
            warnings.filterwarnings('ignore', message='Unknown extension is not supported')
            workbook = openpyxl.load_workbook(io.BytesIO(archive.read('data_akbilgic.xlsx')), read_only=True, data_only=True)
        source_rows = list(workbook.active.values)
        workbook.close()
    if source_rows[0][1] != 'TL BASED' or source_rows[1][:2] != ('date', 'ISE'):
        raise ValueError('Unexpected source schema; stop rather than guess the target column.')
    records = []
    for source_row in source_rows[2:]:
        if not isinstance(source_row[0], datetime):
            raise ValueError('Invalid source date')
        records.append({'date': source_row[0].date().isoformat(), 'return': source_row[1]})
    validate_records(records)
    return records


def validate_records(records):
    if len(records) < 21:
        raise ValueError('At least 21 records required')
    for index, record in enumerate(records):
        parsed = datetime.strptime(record['date'], '%Y-%m-%d')
        if parsed.date().isoformat() != record['date']:
            raise ValueError('Noncanonical date')
        value = record['return']
        if isinstance(value, bool) or not isinstance(value, (int, float)) or not np.isfinite(value):
            raise ValueError('Invalid return')
        if index and record['date'] <= records[index - 1]['date']:
            raise ValueError('Dates must strictly increase')


def build_samples(records):
    validate_records(records)
    returns = np.array([record['return'] for record in records], dtype=float)
    samples = []
    for target_index in range(20, len(records)):
        history = returns[target_index - 20:target_index]
        features = [history[-1], history[-2], history[-5], history[-5:].mean(),
                    history[-5:].std(), history.mean(), history.std()]
        samples.append({'date': records[target_index]['date'],
                        'information_date': records[target_index - 1]['date'],
                        'features': [float(value) for value in features],
                        'label': int(returns[target_index] > 0),
                        'return': float(returns[target_index])})
    return samples


def split_samples(samples):
    partitions = {
        'train': [sample for sample in samples if sample['date'] <= '2009-12-31'],
        'validation': [sample for sample in samples if '2010-01-01' <= sample['date'] <= '2010-06-30'],
        'test': [sample for sample in samples if sample['date'] >= '2010-07-01'],
    }
    if any(not partition for partition in partitions.values()):
        raise ValueError('Empty time partition')
    return partitions


def arrays(samples):
    return np.array([sample['features'] for sample in samples]), np.array([sample['label'] for sample in samples])


def select_model(train, validation):
    train_features, train_labels = arrays(train)
    valid_features, valid_labels = arrays(validation)
    if len(np.unique(train_labels)) != 2:
        raise ValueError('Training needs both classes')
    candidates = []
    models = []
    for regularization in CANDIDATES:
        model = make_pipeline(StandardScaler(), LogisticRegression(
            C=regularization, solver='lbfgs', max_iter=2000, tol=1e-8, random_state=42))
        with warnings.catch_warnings():
            warnings.simplefilter('error', ConvergenceWarning)
            model.fit(train_features, train_labels)
        probability = model.predict_proba(valid_features)[:, 1]
        candidates.append({'C': regularization, 'validation_log_loss': float(log_loss(valid_labels, probability, labels=[0, 1]))})
        models.append(model)
    best_index = min(range(len(candidates)), key=lambda index: (candidates[index]['validation_log_loss'], candidates[index]['C']))
    return models[best_index], candidates, candidates[best_index]['C']


def metrics(labels, probability):
    predicted = (np.asarray(probability) >= 0.5).astype(int)
    both_classes = len(np.unique(labels)) == 2
    return {'accuracy': float(accuracy_score(labels, predicted)),
            'balanced_accuracy': float(balanced_accuracy_score(labels, predicted)) if both_classes else None,
            'log_loss': float(log_loss(labels, probability, labels=[0, 1])),
            'roc_auc': float(roc_auc_score(labels, probability)) if both_classes else None,
            'confusion_matrix': confusion_matrix(labels, predicted, labels=[0, 1]).tolist()}


def run_experiment(records):
    samples = build_samples(records)
    partitions = split_samples(samples)
    model, candidates, selected = select_model(partitions['train'], partitions['validation'])
    train_features, train_labels = arrays(partitions['train'])
    majority_probability = float(train_labels.mean())
    results = {}
    predictions = []
    for name, partition in partitions.items():
        features, labels = arrays(partition)
        probability = model.predict_proba(features)[:, 1]
        majority = np.full(len(labels), majority_probability)
        persistence = (features[:, 0] > 0).astype(int)
        results[name] = {
            'start': partition[0]['date'], 'end': partition[-1]['date'], 'count': len(partition),
            'up_count': int(labels.sum()), 'model': metrics(labels, probability),
            'majority': metrics(labels, majority),
            'persistence_accuracy': float(accuracy_score(labels, persistence)),
        }
        if name == 'test':
            for sample, chance in zip(partition, probability):
                predictions.append({'date': sample['date'], 'information_date': sample['information_date'],
                                    'actual': sample['label'], 'probability_up': float(chance),
                                    'predicted': int(chance >= 0.5), 'majority_predicted': int(majority_probability >= 0.5)})
    scaler = model.named_steps['standardscaler']
    classifier = model.named_steps['logisticregression']
    return {
        'experiment': 'ISE-direction-v1', 'rule_date': '2026-10-14',
        'source': {'name': 'UCI ISTANBUL STOCK EXCHANGE', 'url': SOURCE_URL,
                   'doi': '10.24432/C54P4J', 'author': 'Oguz Akbilgic (2013)', 'license': 'CC BY 4.0',
                   'target_column': 'first ISE / TL BASED', 'raw_count': len(records),
                   'start': records[0]['date'], 'end': records[-1]['date'],
                   'date_discrepancy': 'UCI summary says Jun 5, 2009; Excel starts 2009-01-05. Excel dates retained.'},
        'config': {'features': FEATURES, 'warmup': 20, 'C_candidates': CANDIDATES, 'selected_C': selected,
                   'threshold': 0.5, 'seed': 42, 'refit_on_validation': False, 'majority_probability': majority_probability},
        'validation_candidates': candidates, 'splits': results,
        'fitted': {'mean': scaler.mean_.tolist(), 'scale': scaler.scale_.tolist(),
                   'coefficients': classifier.coef_[0].tolist(), 'intercept': float(classifier.intercept_[0])},
        'environment': {'python': platform.python_version(), 'numpy': np.__version__,
                        'sklearn': sklearn.__version__, 'openpyxl': openpyxl.__version__},
        'predictions': predictions,
    }


def main():
    raw_path = ROOT / 'data' / 'istanbul-stock-exchange.zip'
    records = read_source(raw_path)
    report = run_experiment(records)
    report['source']['sha256'] = hashlib.sha256(raw_path.read_bytes()).hexdigest()
    report['source']['retrieved_date'] = '2026-10-14'
    report['code_sha256'] = hashlib.sha256(Path(__file__).read_bytes()).hexdigest()
    report['spec_sha256'] = hashlib.sha256((ROOT / 'EXPERIMENT.md').read_bytes()).hexdigest()
    report_json = json.dumps(report, ensure_ascii=False, indent=2, allow_nan=False)
    (ROOT / 'report.json').write_text(report_json + '\n', encoding='utf-8')
    (ROOT.parent / 'research-results.js').write_text('window.QuantResearch = ' + report_json + ';\n', encoding='utf-8')
    with (ROOT / 'predictions.csv').open('w', encoding='utf-8', newline='') as output:
        writer = csv.DictWriter(output, fieldnames=list(report['predictions'][0]))
        writer.writeheader()
        writer.writerows(report['predictions'])
    with (ROOT / 'data' / 'ise-returns.csv').open('w', encoding='utf-8', newline='') as output:
        writer = csv.DictWriter(output, fieldnames=['date', 'return'])
        writer.writeheader()
        writer.writerows(records)
    print(json.dumps({'selected_C': report['config']['selected_C'], 'splits': report['splits']}, indent=2))


if __name__ == '__main__':
    main()
